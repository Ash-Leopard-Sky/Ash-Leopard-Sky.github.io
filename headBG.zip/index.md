<!DOCTYPE html>
<html>
<head>
	<title>Sinlepage Site</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="siteBlock" id="header">
		<img src="logo.jpg">
		<form id="headerButGoog" action="https://www.google.com">
			<button id="butGoog" type="submit">
				GOOGLE
			</button>
		</form>
		<div class="textWithButton">
			<span class="textBig">
				GOOGLE
			</span>
			<span class="textLite">
				Incredible search service
			</span>
			<form action="https://www.google.com">
				<button class="textBig" id="butGoog" type="submit">
					GOOGLE
				</button>
			</form>
		</div>
	</div>
	<div class="siteBlock" id="animButton">
		<form action="#header">
			<button class="textBig" id="butGoup" type="submit">
				GO UP
			</button>
		</form>
	</div>
	<div class="siteBlock" id="emptyBlock">
		
	</div>
	<div class="siteBlock" id="footer">
		<span id="urls">
			<a href="#header">Go up</a>
			<a href="#animButton">Button</a>
			<a href="#emptyBlock">EMPTY</a>
		</span>
		<span id="credits">
			Bla bla this page author from russia.<br>HA.<br>HA.
		</span>
		<span id="infos">
			<a href="https://vk.com/404">JOKE</a>
		</span>
	</div>
</body>
</html>